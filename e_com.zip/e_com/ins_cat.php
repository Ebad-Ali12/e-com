<section class="container text-light pt-5" style="width:100%;">
    <form action="" method="post" class="d-flex"
        style="justify-content:center;align-items:center;flex-direction:column;width:100%;">
        <div class="mb-3 row" style="width:100%;">
            <!-- <label for="cate" class="form-label col-lg-2" style="font-size:25px">Categories</label> -->
            <input type="text" name="ins_cat" id="cate" placeholder="Insert New Category" class="form-control"
                style="width:100%;">
        </div>
        <button type="submit" class="btn btn-primary" name="add_cat">Add Category</button>
    </form>
</section>

<div class="toast-container position-fixed bottom-0 end-0 p-3 ">
  <div id="liveToast" class="toast bg-success text-light" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header ">
    <i class="fa-solid fa-circle-dot"></i>
        <strong class="me-auto"> Alert</strong>
      <small></small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body ">
       hello
    </div>
  </div>
</div>