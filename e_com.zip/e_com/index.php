<?php
include "db.php";
$query = "SELECT * FROM `items`";
$result = mysqli_query($con, $query);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ebad's Daraz</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" href="https://cdn.iconscout.com/icon/free/png-256/free-ecommerce-icon-download-in-svg-png-gif-file-formats--services-solution-cart-online-web-seo-development-vol-1-pack-design-icons-8830.png?f=webp&w=256" type="image/x-icon">
</head>

<body>
    <?php include "navbar.php" ?>
    <!-- <div class="modal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Modal body text goes here.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div> -->
    <section id="auto">
        <div class="subtile bg-warning text-center">
            <h1 class="">Cart Shop</h1>
            <p>Your one-stop shop for all your needs. <span class="type"></span></p>
        </div>
    </section>
    <section>
        <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="10000">
                    <img src="https://st3.depositphotos.com/1177973/12669/i/450/depositphotos_126693854-stock-photo-set-of-body-care-products.jpg"
                        class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item" data-bs-interval="2000">
                    <img src="https://www.moroccanoil.com/cdn/shop/products/d1512a-mo.-com-_pcr-logo-resize_mot-reanimation_hydratingstylingcream.jpg?v=1719875497&width=1946"
                        class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="https://media.istockphoto.com/id/1320934166/photo/cosmetic-skin-care-products-on-green-leaves.jpg?s=612x612&w=0&k=20&c=X4pwnTaBzXHDOGZlcdJdlKxmYd__61xboHVIiR5JMIk="
                        class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
    <section class="container">
        <div class="row container  mt-5 chg">
        <?php
            // if(isset($_POST['search_btn'])){
            //     $searched = $_POST['search'];
            //     $sql = "SELECT * FROM `items` WHERE `title` LIKE '%$searched%' OR `categories` LIKE '%$searched%'";
            //     $result7 =mysqli_query($con,$sql);
            //     if($result7 && mysqli_num_rows($result7)>0){
                  
            //         exit();
            //     }
            //     else{
            //         echo"<h1 class='text-center mt-5 pt-5 text-danger' style='height:60vh;'>No Item Found...</h1>";
            //     }
            // }
            
            
            ?>
        </div>
        
    </section>
    <div class="fixedm">
        <i class="fa-solid fa-cart-shopping fa-fade" data-bs-toggle="modal" data-bs-target="#exampleModal"></i>
      
    </div>
   
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Total Price</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body fixed"  >
        
      </div>
      <p class="ml">Total price is in header</p>
      <div class="modal-footer">
        <form action="" method="post">
            <button type="submit" class="btn btn-secondary bg-success pay"  name="pay">Confirm Payment</button>
        </form>
        <button type="button" class="btn btn-secondary bg-warning clr" >clear</button>
        <button type="button" class="btn btn-secondary bg-danger " data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
    <footer>
        <h1>&copy; Copyrights reserved by Ebad's Daraz. </h1>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.10/typed.js"
        integrity="sha512-tQQXRDB2wEmuJGtFrmmoFYzNTq8StA1XJrfO0OQbbTxd9G0CwaTDL6/C1y805IlvBVrMwOqob1kf6r/2U5XXVg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        var type = new Typed(".type", {
            strings: ["quality products", "unbeatable prices", "fast delivery"],
            typeSpeed: 110,
            backSpeed: 100,
            loop: true
        })
    </script>
    <script>
       let search = document.getElementById("search");
const product = [
    <?php
        $query6 = "SELECT * FROM `items`";
        $result8 = mysqli_query($con, $query6);
        while ($row = mysqli_fetch_assoc($result8)) {
            echo "
            {
                id: {$row['id']},
                title: '{$row['title']}',
                img: 'images/{$row['image']}',
                price: {$row['price']},
                des: '{$row['product_des']}'
            },";
                
        }
    ?>
];

const categories = [...new Set(product.map(item => item))];

search.addEventListener("input", (e) => {
    let searchdata = e.target.value.toLowerCase();
    const filtered = categories.filter(item => {
        return item.title.toLowerCase().includes(searchdata);
    });
    displayitem(filtered);
});

const displayitem = (items) => {
    let root = document.getElementsByClassName("chg")[0];
    root.innerHTML = items.map(item => {
        const { id, title, img, price, des } = item;
        return `
            <div class='card col-lg-4 mx-2 mb-4' style='width: 14rem;'>
                <img src='${img}' class='card-img-top' alt='Not Available' style='height:200px;width:100%;margin-right:10px !important;object-fit:cover;'>
                <div class='card-body'>
                    <h5 class='card-title'>${title}</h5>
                    <p class='card-text'>Rs <span>${price}.00</span>/-</p>
                    <p class='card-text des'>${des}</p>
                    <button class='btn btn-success atc' data-id='${id}' data-name='${title}' data-price='${price}'>Add to cart</button>
                    <a href='details.php?id=${id*23509876}' class='btn btn-info'>View More</a>
                </div>
            </div>`;
    }).join(""); // Join array to a single string
};

displayitem(categories);
    </script>
    <script>
var cart = JSON.parse(localStorage.getItem('cart')) || [];
// Function to add an item to the cart
function addToCart(item) {
    // Check if the item already exists in the cart
    const index = cart.findIndex(cartItem => cartItem.id === item.id);

    if (index !== -1) {
        // If item already exists, increase the quantity
        cart[index].quantity += 1;
    } else {
        // If item is new, add it to the cart with quantity 1
        item.quantity = 1;
        cart.push(item);
    }

    // Save the updated cart to local storage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Update the cart display
    displayCart();
}

// Function to display the cart
function displayCart() {
    const cartContainer = document.querySelector('.fixed'); // Assume there's a cart container on your page
    const totalPriceElement = document.querySelector('.cart'); // Element to display the total price
    cartContainer.innerHTML = ''; // Clear existing content

    let totalPrice = 0;
    
    // Display each item in the cart
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        totalPrice += itemTotal;

        const cartItem = document.createElement('div');
        cartItem.innerHTML = `
            <p>${item.name} - ${item.price} x ${item.quantity} = ${itemTotal}</p>`;
            cartContainer.appendChild(cartItem);
        });
        
        // Display the total price
        totalPriceElement.textContent = `Total: Rs ${totalPrice.toFixed(2)}/-`;
    }

// Example of adding an item to the cart on button click
let items2 = document.getElementsByClassName('atc');
for(let i = 0; i < items2.length; i++){
    items2[i].addEventListener('click', () => {
        // Sample item details - adjust to your needs
        const item = {
            id: items2[i].getAttribute('data-id'),
            name: items2[i].getAttribute('data-name'),
            price: parseFloat(items2[i].getAttribute('data-price'))
        };
        addToCart(item);
    });
}

// Call displayCart initially to load cart items on page load
displayCart();

// Clear cart function
document.querySelector('.clr').addEventListener('click', () => {
    localStorage.removeItem("cart"); // Remove the "cart" item from local storage
    cart = []; // Clear the cart array in memory
    displayCart(); // Update the cart display on the page
    console.log("Cart has been cleared");
});
    
// Function to send cart data to PHP

    function sendCartData() {
        event.preventDefault()
        const cartData = JSON.parse(localStorage.getItem('cart')) || [];
    fetch("save_cart.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(cartData)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data)
        if (data.success) {
            alert("Cart data saved successfully!");
            localStorage.removeItem("cart"); // Optionally clear the cart after sending
            cart = []; // Clear cart in memory
            displayCart(); // Update the cart display
        } else {
            alert("Error saving cart data.");
        }
    })

    .catch(error => console.error("Error:", error));
}

// Example of calling sendCartData on button click
document.querySelector('.pay').addEventListener('click', () => {
    sendCartData();
   
    // console.log(true);
    
});

</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>