<?php
// session_start();
include "db.php";
if (isset($_POST["submit"])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $cat1 = $_POST['cat'];
    $filename = $_FILES['img']['name'];
    $tempname = $_FILES['img']['tmp_name'];
    // $folder = `./images/`.$filename;
    move_uploaded_file($tempname, "./images/$filename");
    $pd = $_POST['pd'];
    $query = "INSERT INTO `items` (`title`, `price`, `image`,`categories`,`product_des`) VALUES ('$title', '$price', '$filename','$cat1','$pd')";
    $result = mysqli_query($con, $query);
}
$query1 = "SELECT * FROM `items`";
$result1 = mysqli_query($con, $query1);
$i = 1;


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="shortcut icon" href="images/admin.jpg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <nav class="container-fluid row bg-warning m-0" id="dash">
        <div class="col-lg-4"><img src="images/admin.png" alt=""></div>
        <div class="col-lg-8">
            <h1>Dashboard</h1>
        </div>
        <div>
            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"><i class="fa-solid fa-bars"></i></button>
        </div>
    </nav>
    

<div class="offcanvas offcanvas-start bg-warning text-dark" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">DB-Options</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
            <button><a href="dashboard.php?view_cat">View Products</a></button>
            <button><a href="dashboard.php?ins_pro">Insert Product</a></button>
            <button><a href="dashboard.php?ins_cat">Insert Category</a></button> 
            <button><a href="">All Orders</a></button>
            <button><a href="">All Payments</a></button>
            <button><a href="">List Users</a></button>
            <button><a href="">Logout</a></button>
  </div>
</div>
<div class="bg-dark change" >
        
    <?php
    if(!isset($_GET["ins_pro"]) && !isset($_GET['view_cat']) && !isset($_GET['ins_cat'])){
        
        echo "<h1 class='db_text'>Select an Option in drawer to functionalize dashboard</h1>";
    }
    else{
    }
    if(isset($_GET["ins_pro"])){
        include "insert.php";
        if(isset($_POST['submit'])){
            echo"<script>
            liveToast
            let title =document.querySelector('.toast-body')
            document.addEventListener('DOMContentLoaded', function () {
            title.innerHTML='New Product has been inserted successfully'
            var toastElement = document.getElementById('liveToast');
            var toast = new bootstrap.Toast(toastElement);
            toast.show();
            });
        </script>"; 
        }
      
    }
    elseif(isset($_GET['view_cat'])){
        include "view.php";
        
    }
    elseif(isset($_GET['ins_cat'])){
        include "ins_cat.php";
        if(isset($_POST['add_cat'])){
            $cat = $_POST['ins_cat'];
            $catn = strtoupper($cat);   
                if(!empty($catn)){
                    
                    $query5= "SELECT * From `category` Where `cat`='$catn'";
                    $result5 = mysqli_query($con,$query5);
                    $num = mysqli_num_rows($result5);
                    
                    if($num<1){
                        $query4= "INSERT INTO `category` (`cat`) VALUES ('$catn')";
                        $result3 = mysqli_query($con,$query4);
                        echo"<script>
                            let title =document.querySelector('.toast-body')
                            document.addEventListener('DOMContentLoaded', function () {
                            title.innerHTML='New Category has been updated successfully'
                            var toastElement = document.getElementById('liveToast');
                            var toast = new bootstrap.Toast(toastElement);
                            toast.show();
                            });
                        </script>";        
                    }
                    else{
                        echo"<script>
                        var liveToast =document.querySelector('#liveToast')
                        let title =document.querySelector('.toast-body')
                        document.addEventListener('DOMContentLoaded', function () {
                            liveToast.classList.add('bg-danger')
                        title.innerHTML='This category is already exits!'
                        var toastElement = document.getElementById('liveToast');
                        var toast = new bootstrap.Toast(toastElement);
                        toast.show();
                        });
                    </script>"; 
                    }
                
            }
        }
        }

    ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
    </script>
    
</body>

</html>