<?php
include "navbar.php";
include "db.php";
if (isset($_GET['id'])) {
    $ido = $_GET['id'];
    $id = $ido/23509876;
    $title = null;
    $price = null;
    $des = null;
    $img = null;
    $stmt = $con->prepare("SELECT * FROM `items` WHERE `id` = ?");
    $stmt->bind_param("i", $id);

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $title = $row['title'];
        $price = $row['price'];
        $des = $row['product_des'];
        $img = $row['image'];
    }

    $stmt->close();
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title><?php echo $title ?>-details</title>
</head>
<style>
    * {
        font-family: sans-serif;
    }
    body{
        background-color: black;
        color: white;
    }
    .img {
        height: 400px;
        width: 100%;
        box-shadow: 0 0px 5px yellow;
        background-color: black;

        /* box-shadow: inset 0 0 5px black; */
        /* padding: 10px 2; */
        & img {
            height: 100%;
            width: 100%;
            object-fit: contain;
        }
    }

    .main {
        height: fit-content;
        padding: 0 40px;
    }

    h2 {
        text-transform: capitalize;
        font-weight: 700;
        margin-top: 30px;
        font-size: 39px;
    }

    h4 {
        font-size: 20px;
        margin-top: 20px;
    }
    .des{
        text-transform: capitalize;
    }
    span{
        font-size: 25px;
    }
</style>

<body>
    <section>
        <div class="img">
            <img src="images/<?php echo $img ?>" alt="preview not available">
        </div>
        <div class="main">

            <h2><span>Product:</span> <?php echo $title ?></h2>
            <h4>Rs <?php echo $price ?>/-</h4>
            <p class="des"><?php echo $des ?></p>
            <p>
                <b><h4>Product Description:</h4></b>
                <b>Features:</b>

                Wireless Bluetooth 5.0 <br>
                Noise Cancellation <br>
                24-Hour Battery Life <br>
                Comfortable Over-Ear Design with Memory Foam <br>
                Quick Charge (10 minutes for 3 hours of playtime) <br>
                <b>Benefits:</b>

                Enjoy an immersive listening experience with top-notch sound quality. <br>
                Ideal for work-from-home setups, gym sessions, or long commutes. <br>
                Durable and comfortable enough for all-day wear.<br>
                <b>Pricing</b>
                Price: <b> <u>Pkr <?php echo $price?> </u></b> (Originally <b>Pkr <?php echo $price + (($price/100)*30)?></b> - <b>Save 30%!</b>) <br>
                Discount: Limited Time Offer! <br>
                <b>Customer Reviews</b> <br>
                ⭐⭐⭐⭐☆ (4.5/5 based on 102 reviews) <br>

                "Great sound quality and very comfortable for long use!" - Jane D.
                "Perfect for traveling; the battery life is amazing." - Mike S. <br>
                <b>Return Policy</b> <br>
                30-Day Money-Back Guarantee  <br>
                1-Year Warranty <br>
                Add to Cart <br>
                Add to Cart | In Stock: Only 12 Left! <br>

                <b>Need Help?</b> <br>
                Contact our Customer Support for any questions.


            </p>
        </div>
    </section>
    <footer>
        <h1>&copy; Copyrights reserved by Ebad's Daraz. </h1>
    </footer>
    <script>
//         let cart = JSON.parse(localStorage.getItem('cart')) || [];

// // Function to add an item to the cart
// function addToCart(item) {
//     // Check if the item already exists in the cart
//     const index = cart.findIndex(cartItem => cartItem.id === item.id);

//     if (index !== -1) {
//         // If item already exists, increase the quantity
//         cart[index].quantity += 1;
//     } else {
//         // If item is new, add it to the cart with quantity 1
//         item.quantity = 1;
//         cart.push(item);
//     }

//     // Save the updated cart to local storage
//     localStorage.setItem('cart', JSON.stringify(cart));

//     // Update the cart display
//     displayCart();
// }

// // Function to display the cart
// function displayCart() {
//     const cartContainer = document.querySelector('.fixed'); // Assume there's a cart container on your page
//     const totalPriceElement = document.querySelector('.cart'); // Element to display the total price
//     cartContainer.innerHTML = ''; // Clear existing content

//     let totalPrice = 0;

//     // Display each item in the cart
//     cart.forEach(item => {
//         const itemTotal = item.price * item.quantity;
//         totalPrice += itemTotal;

//         const cartItem = document.createElement('div');
//         cartItem.innerHTML = `
//             <p>${item.name} - ${item.price} x ${item.quantity} = ${itemTotal}</p>
            
//         `;
//         // cartItem.innerHTML = `
//         //     <p>Total price ${itemTotal}</p>
//         // `;
//         cartContainer.appendChild(cartItem);
//     });

//     // Display the total price
//     totalPriceElement.textContent = `Total: Rs ${totalPrice.toFixed(2)}/-`;
// }

// // Example of adding an item to the cart on button click
// let items2 = document.getElementsByClassName('atc');
// for(let i = 0; i < items2.length; i++){
//     items2[i].addEventListener('click', () => {
//         // Sample item details - adjust to your needs
//         const item = {
//             id: items2[i].getAttribute('data-id'),
//             name: items2[i].getAttribute('data-name'),
//             price: parseFloat(items2[i].getAttribute('data-price'))
//         };
//         addToCart(item);
//     });
// }

// // Call displayCart initially to load cart items on page load
// displayCart();

// // Clear cart function
// document.querySelector('.clr').addEventListener('click', () => {
//     localStorage.removeItem("cart"); // Remove the "cart" item from local storage
//     cart = []; // Clear the cart array in memory
//     displayCart(); // Update the cart display on the page
//     console.log("Cart has been cleared");
// });
document.querySelector('.cart').innerHTML = "";
    </script>
</body>

</html>