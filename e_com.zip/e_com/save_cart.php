<?php
include "db.php";
// Retrieve and decode the JSON data from JavaScript
$cartData = json_decode(file_get_contents("php://input"), true);

$response = ["success" => false];
// echo json_encode($cartData); 
if (!empty($cartData)) {
    // Prepare SQL statement
    $stmt = $con->prepare("INSERT INTO `cart` (product_id, name1, quantity, price) VALUES (?, ?, ?, ?)");

    foreach ($cartData as $item) {
        $stmt->bind_param("isid", $item['id'], $item['name'], $item['quantity'], $item['price']);
        $stmt->execute();
    }

    $response["success"] = true;
    $stmt->close();
}

$con->close();

// Send a response back to JavaScript
header("Content-Type: application/json");
echo json_encode($response);
?>
