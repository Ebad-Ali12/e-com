<h1 class="text-light text-center pt-3" style="font-size: 25px;"></h1>
<section class='bg-dark'>
<div class="container table_div">
            <table class="table">
                <thead >
                    <tr style="vertical-align:middle;">
                        <th scope="col" >ID</th>
                        <th scope="col" style="text-align:center">Product Title</th>
                        <th scope="col" style="text-align:center">Product Price</th>
                        <th scope="col">Product Image</th>
                        <th scope="col" >Item Sold</th>
                        <th scope="col">Category</th>
                        <th scope="col">Product Description</th>
                        <th scope="col">Date</th>
                        <th scope="col">Update</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    while ($row = mysqli_fetch_assoc($result1)) {
                        $change = $row['id'];
                        echo "
                    
                    <tr>
                    <th scope='row' style='vertical-align: middle;'>$i</th>
                    <td style='vertical-align: middle;text-align:center;'>$row[title]</td>
                    <td style='vertical-align: middle; text-align:center;'>$row[price]</td>
                    <td><img src='images/$row[image]' height = '70px' width = '70px'></td>
                    <td style='vertical-align: middle; '>1</td>
                    <td style='vertical-align: middle; '>$row[categories]</td>
                    <td style='vertical-align: middle; '>$row[product_des]</td>
                    <td style='vertical-align: middle; '>$row[date]</td>
                    <input type='hidden' value = '$row[image]' name = 'img'>
                    <input type='hidden' value = '{$change}' name = 'update'>
                    <th scope='row' style='vertical-align: middle;margin:auto'><button class='btn btn-primary' name='ubtn'><a href='update.php?id=$change' class='text-light'>Update</a></button></th>
                    <form action='delete.php' method='post'>
                    <input type='hidden' value = '{$change}' name = 'delete'>   
                    <th scope='row' style='vertical-align: middle;'><button class='btn btn-danger' name='dbtn'>Delete</button></button></th>
                    </form>
                </tr>";
                        $i++;
                    }

                    ?>

                </tbody>

            </table>
</div>
</section>