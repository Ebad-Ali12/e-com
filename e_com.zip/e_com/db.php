<?php

$host = "localhost";
$name = "root";
$pass = "";
$db = "e-com";
$con = mysqli_connect($host, $name, $pass, $db);
if (!$con) {
    die();
}
else{
    // echo"ok";
}
?>