<?php

include "db.php";
$change = null;
$product = null;
$price =null;
$image= null;
$des = null;
if (isset($_GET['id'])) {
    $change = $_GET['id'];
    $query = "SELECT * FROM `items` WHERE `id` = $change";
    $result = mysqli_query($con, $query);   
    while ($row = mysqli_fetch_assoc($result)) {
        $product = $row['title'];
        $price = $row['price'];
        $image = $row['image'];
        $des = $row['product_des'];
    }};  

$new = $change;
if (isset($_POST['updatep'])) {
    $tempname = null;

    $filename = $image;
    $folder = $image;
    if (!empty($_FILES['img2']['name'])) {
        $tempname = $_FILES['img2']['tmp_name'];
        $filename = $_FILES['img2']['name'];
        // $folder = "./images/".$filename;
        move_uploaded_file($tempname, "./images/$filename");
    }
    $title1 = $_POST['title1'];
    $price1 = $_POST['price1'];
    $cati = $_POST['cati'];
    $pdn = $_POST['pdn'];
    $query1 = "UPDATE `items` SET `title` = '$title1', `price` = $price1, `image` = '$filename',`categories` = '$cati',`product_des` = '$pdn' WHERE `id` = $new";
    $result2 = mysqli_query($con, $query1);
    if ($result2) {
        header("location:dashboard.php?view_cat");
    }
    else{
        echo "update not successful";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="shortcut icon" href="images/admin.jpg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
<nav class="container-fluid row bg-warning m-0" id="dash">
        <div class="col-lg-4"><img src="images/admin.png" alt=""></div>
        <div class="col-lg-8">
            <h1>Dashboard</h1>
        </div>
        <div>
            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"><i class="fa-solid fa-bars"></i></button>
        </div>
    </nav>
    

<div class="offcanvas offcanvas-start bg-warning text-dark" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">DB-Options</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
            <button><a href="dashboard.php?view_cat">View Products</a></button>
            <button><a href="dashboard.php?ins_pro">Insert Product</a></button>
            <button><a href="dashboard.php?ins_cat">Insert Category</a></button> 
            <button><a href="">All Orders</a></button>
            <button><a href="">All Payments</a></button>
            <button><a href="">List Users</a></button>
            <button><a href="">Logout</a></button>
  </div>
</div>
    <section class="bg-dark text-light db">
        <form class="container" method="post" enctype="multipart/form-data">
            <div class="row mb-3 ">
                <label for="inputEmail3" class="col-sm-2 col-form-label">Product Title</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputEmail3" name="title1"
                        value="<?php echo $product ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Product Price</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" id="inputPassword3" name="price1"
                        value="<?php echo $price ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="formFile" class="form-label col-lg-2">New Product Image</label>
                <div class="col-sm-10">
                    <input class="form-control col-lg-10" type="file" id="formFile" name="img2">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="cate" class="form-label col-lg-2">update Category</label>
                <div class="col-sm-10">
                    <select name="cati" id="cate" >
                        <?php
                            $query6 = "SELECT * FROM `category`";
                            $result6 = mysqli_query($con,$query6);
                            while($row = mysqli_fetch_assoc($result6)){
                            echo  "<option value='$row[cat]' selected='BOOK'>$row[cat]</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="pd" class="form-label col-lg-2">Update Product description</label>
                <div class="col-sm-10">
                    <input class="form-control col-lg-10" type="text" id="pd" name="pdn" value="<?php echo $des?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary" name="updatep">Update Product</button>
        </form>
        <div class=" bg-dark text-danger text-center py-4">
            <div class="container">
                <h1>Current Images</h1>
                <img src="images/<?php echo $image ?>" alt="Image not found" height="100" width="100">
            </div>
        </div>

    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script$pd1>
</body>

</html>