<?php
// session_start();
// echo $_SESSION['change'];
include "db.php";
$change;
if (isset($_POST['dbtn'])) {
    $change = $_POST['delete'];
    $query = "DELETE FROM `items` WHERE `id` = $change";
    $result = mysqli_query($con, $query);
}
if($result){
    header("location:dashboard.php?view_cat");
}
else{
    echo "Not deleted";
}
?>