<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="shortcut icon" href="images/login.png" type="image/x-icon">
</head>
<style>
    body{
        height: 100vh;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    h1{
        margin-top: 12px;
        font-size: 30px;
    }
    .container{
        height: 375px;
        width: 325px;
        /* border: 1px solid red; */
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        /* box-shadow: 0 0 40px rgb(151, 26, 26); */
        overflow: hidden;
        z-index: 99;
        /* background-color: black; */
        justify-content: center;
    }
    input{
        background-color: transparent;
        border: none;
        border-bottom: 1px solid red;
        outline: none;
        width: 100%;
        margin-top: 20px;
        padding: 2px 2px;
        color: white;
    }
    button{
        background-color: transparent;
        border: none;
        color: white;
        /* width: 30%; */
        /* margin: 20px 0; */
    }
    button:first-of-type{
        width: 100%;
        margin: 20px 0;
        background-color: hsla(0, 100%, 50%, 0.501);
        padding: 4px 0 6px 0;
    }
    .container>div{
        height: 370px;
        width: 320px;
        padding: 10px 10px;
    }
    .container::before{
        content: "";
        height: 100%;
        width: 110%;
        background-image:conic-gradient(rgb(169, 7, 7) 20deg,transparent 150deg,rgb(169, 7, 7) 260deg);
        position: absolute;
        z-index: -100;
        animation: rotate;
        animation-duration: 1.5s;
        animation-iteration-count: infinite;
        animation-timing-function:linear;
    }
    @keyframes rotate {
        0%{
            transform: rotate(0deg);
        }
        100%{
            transform: rotate(360deg);
        }
    }
    .container::after{
        content: "";
        height: 100%;
        width: 100%;
        filter :blur(10px);
        background-color:rgb(169, 7, 7);
        position: absolute;
        z-index: -100;
    }
    a{
        text-decoration: none;
    }
</style>
<body class="bg-dark">
    <div class="container text-light ">
        <div class="bg-dark ">
        <h1 class="text-center">Login</h1>
        <form action="">
            <input type="text" name="" id="" placeholder="Enter Your Email">
            <input type="password" name="" id="" placeholder="Password">
            <button>Sign in</button>
            <button>Register now <span class="text-primary"><a href="sign_up.php">Sign Up</a></span></button>
        </form>
        </div>
    </div>
</body>
</html>