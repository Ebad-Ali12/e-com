<section class="bg-dark text-light db">
        <form class="container" action="" method="post" enctype="multipart/form-data">
            <div class="row mb-3 ">
                <label for="inputEmail3" class="col-sm-2 col-form-label">Product Title</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputEmail3" name="title" required autocomplete = "off">
                </div>
            </div>
            <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Product Price</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" id="inputPassword3" name="price" required autocomplete = "off">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="formFile" class="form-label col-lg-2">Product Image</label>
                <div class="col-sm-10">
                    <input class="form-control col-lg-10" type="file" id="formFile" name="img" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="cate" class="form-label col-lg-2">Categories</label>
                <div class="col-sm-10">
                    <select name="cat" id="cate" required>
                        <?php
                            $query6 = "SELECT * FROM `category`";
                            $result6 = mysqli_query($con,$query6);
                            while($row = mysqli_fetch_assoc($result6)){
                            echo  "<option value='$row[cat]'>$row[cat]</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="pd" class="form-label col-lg-2">Product Description</label>
                <div class="col-sm-10">
                    <input class="form-control col-lg-10" type="text" id="pd" name="pd" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Add Product</button>
        </form>
       
    </section>
    <div class="toast-container position-fixed bottom-0 end-0 p-3 ">
  <div id="liveToast" class="toast bg-success text-light" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header ">
    <i class="fa-solid fa-circle-dot"></i>
        <strong class="me-auto"> Alert</strong>
      <small></small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body ">
       hello
    </div>
  </div>
</div>